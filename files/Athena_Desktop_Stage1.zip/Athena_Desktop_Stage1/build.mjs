import fs from 'node:fs/promises'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {fileURLToPath} from 'node:url'
import * as esbuild from 'esbuild'
const root=path.dirname(fileURLToPath(import.meta.url))
const upstream=path.resolve(root,'../hermes-upstream')
const expectedSha='67491b50f7e5ef8be6e591d745b32758aa60c33e'
let hasCheckout=true
try{await fs.access(path.join(upstream,'.git'))}catch(e){if(e.code!=='ENOENT')throw e;hasCheckout=false}
const sha=hasCheckout?execFileSync('git',['rev-parse','HEAD'],{cwd:upstream,encoding:'utf8'}).trim():expectedSha
if(sha!==expectedSha)throw Error('Upstream changed; review required')
await fs.mkdir(path.join(root,'vendor'),{recursive:true})
if(hasCheckout){
 for(const [from,to] of [['src/contrib/registry.ts','registry.ts'],['src/contrib/types.ts','types.ts'],['src/store/sidebar-nav.ts','sidebar-nav.ts']])await fs.copyFile(path.join(upstream,'apps/desktop',from),path.join(root,'vendor',to))
 await fs.copyFile(path.join(upstream,'LICENSE'),path.join(root,'vendor','LICENSE-HERMES.txt'))
 const hashes={}
 for(const name of ['registry.ts','types.ts','sidebar-nav.ts','LICENSE-HERMES.txt'])hashes[name]=createHash('sha256').update(await fs.readFile(path.join(root,'vendor',name))).digest('hex')
 await fs.writeFile(path.join(root,'vendor/origin.json'),JSON.stringify({revision:sha,hashes},null,2))
}else{
 const origin=JSON.parse(await fs.readFile(path.join(root,'vendor/origin.json'),'utf8'))
 if(origin.revision!==expectedSha)throw Error('Wrong vendor revision')
 for(const [name,hash]of Object.entries(origin.hashes))if(createHash('sha256').update(await fs.readFile(path.join(root,'vendor',name))).digest('hex')!==hash)throw Error('Vendor changed: '+name)
}
await fs.mkdir(path.join(root,'dist'),{recursive:true})
const common={bundle:true,loader:{'.css':'text'},target:'es2022',jsx:'automatic',logLevel:'warning'}
const preview=await esbuild.build({...common,entryPoints:[path.join(root,'src/preview.tsx')],format:'iife',write:false,define:{'process.env.NODE_ENV':'"production"'},minify:true})
// CSS as text is explicitly injected by the feature; the preview frame CSS is
// loaded separately here rather than dropped by a side-effect-only text import.
const shellCss=await fs.readFile(path.join(root,'src/preview.css'),'utf8')
let notices='Hermes Desktop contribution sources\n'+await fs.readFile(path.join(root,'vendor/LICENSE-HERMES.txt'),'utf8')
for(const name of ['react','react-dom','scheduler','nanostores'])notices+='\n\n'+name+'\n'+await fs.readFile(path.join(root,'node_modules',name,'LICENSE'),'utf8')
await fs.writeFile(path.join(root,'dist/THIRD_PARTY_NOTICES.txt'),notices)
const code=preview.outputFiles[0].text.replaceAll('</script','<\\/script')
const html='<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data:; connect-src \'none\'; base-uri \'none\'; form-action \'none\'"><title>Афина · прототип адаптации Hermes Desktop</title><style>'+shellCss+'</style></head><body><div id="root"></div><script>'+code+'</script></body></html>'
await fs.writeFile(path.join(root,'dist/Athena_Desktop_Prototype.html'),html+'\n<!--\n'+notices.replaceAll('--','—')+'\n-->')
await esbuild.build({...common,entryPoints:[path.join(root,'src/plugin.tsx')],external:['react','react/*'],format:'esm',outfile:path.join(root,'dist/plugin.js')})
await esbuild.build({...common,entryPoints:[path.join(root,'src/model.ts')],platform:'node',format:'esm',outfile:path.join(root,'dist/model.mjs')})
await esbuild.build({...common,entryPoints:[path.join(root,'vendor/registry.ts')],platform:'node',format:'esm',outfile:path.join(root,'dist/upstream-registry.mjs')})
const manifest={upstream:'https://github.com/NousResearch/hermes-agent',revision:sha,builtAt:new Date().toISOString(),status:'Isolated interactive preview, NOT installed or end-to-end tested in Hermes Desktop',windows10:'Not executed on Windows; source-install candidate only; MSIX minimum is Windows 11 22H2',vendorFiles:['registry.ts','types.ts','sidebar-nav.ts'],network:'No external service calls; preview CSP connect-src none'}
await fs.writeFile(path.join(root,'dist/provenance.json'),JSON.stringify(manifest,null,2))
console.log(JSON.stringify({status:'BUILT',revision:sha,htmlBytes:Buffer.byteLength(html),outputs:['Athena_Desktop_Prototype.html','plugin.js','provenance.json']},null,2))
