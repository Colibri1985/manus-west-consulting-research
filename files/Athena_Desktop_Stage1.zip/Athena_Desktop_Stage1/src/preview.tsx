import React, {useState, useSyncExternalStore, useEffect} from 'react'
import {createRoot} from 'react-dom/client'
import {registry} from '../vendor/registry'
import {applySidebarNavPrefs} from '../vendor/sidebar-nav'
import plugin from './plugin'
import {pages} from './model'

// Preview host: namespace and register exactly the contribution shapes the
// pinned Desktop consumes. This is NOT its gateway, Electron shell or loader.
const disposers:(()=>void)[]=[]
plugin.register({registerMany(items){const dispose=registry.registerMany(items.map(c=>({...c,id:plugin.id+':'+c.id,source:'plugin:'+plugin.id})));disposers.push(dispose);return dispose}})
const getNav=()=>registry.getArea('sidebar.nav')
const listen=(fn:()=>void)=>registry.subscribeArea('sidebar.nav',fn)
function Preview(){
 const nav=useSyncExternalStore(listen,getNav)
 const [path,setPath]=useState(location.hash.slice(1)||'/athena-home'),[help,setHelp]=useState(false)
 useEffect(()=>{const f=()=>setPath(location.hash.slice(1)||'/athena-home');window.addEventListener('hashchange',f);return()=>window.removeEventListener('hashchange',f)},[])
 const routes=registry.getArea('routes'),route=routes.find(r=>(r.data as {path:string}).path===path)
 const ordered=applySidebarNavPrefs([...nav],[])
 function go(to:string){location.hash=to;setPath(to)}
 return <div className="preview-shell"><header className="preview-title"><span><b>Α</b> Афина <small>на основе расширений Hermes Desktop</small></span><span className="preview-limits">ИЗОЛИРОВАННОЕ ПРЕВЬЮ · НЕ УСТАНОВЛЕННЫЙ DESKTOP</span><button onClick={()=>setHelp(!help)}>О прототипе</button></header><div className="preview-layout"><aside className="preview-sidebar"><div className="preview-brand">АФИНА<span>Личное пространство Андрея</span></div><nav aria-label="Разделы Афины">{ordered.map(c=>{const data=c.data as {label:string,path:string,codicon:string};return <button key={c.id} data-nav={data.path} className={data.path===path?'current':''} aria-current={data.path===path?'page':undefined} onClick={()=>go(data.path)}><span>{({home:'◈',account:'◉',project:'▦',tools:'⌘',graph:'↗',book:'▤'} as Record<string,string>)[data.codicon]}</span>{data.label}</button>})}</nav><div className="preview-preserved"><div>Сохраняем в Hermes</div><p>Чат · сессии · файлы<br/>Навыки · настройки</p><span>В этом превью недоступны</span></div><div className="preview-user"><span className="preview-avatar">А</span><div>Андрей<small>Владелец решений</small></div></div></aside><main className="preview-main">{help?<div className="preview-about"><h1>Что именно вы открыли</h1><p>Интерактивное превью новых страниц. React-компоненты зарегистрированы в настоящем реестре contributions из зафиксированных исходников Hermes Desktop.</p><p>Внешняя рамка окна и навигация здесь упрощены. Это не запущенный Hermes Desktop, не связь с Афиной и не защита закрытых данных.</p><p>Никаких сетевых запросов, ключей и подключений. Только синтетические записи и демосогласования в браузере. Не используйте для рабочих данных.</p><p>Ревизия основы: <code>67491b50f7e5ef8be6e591d745b32758aa60c33e</code>.</p><button onClick={()=>setHelp(false)}>Вернуться к просмотру</button></div>:route?.render?.()||<div className="preview-about"><h1>Раздел не найден</h1><button onClick={()=>go('/athena-home')}>На Главную</button></div>}</main><aside className="preview-agent"><div className="preview-agent-head"><span>Α</span><b>Афина</b></div><div className="preview-offline">Нет соединения с агентом</div><h3>Один помощник.<br/>Несколько рабочих пространств.</h3><p>В Desktop здесь можно сохранить разговор и контекст работы. Этот блок только показывает место чата в целевом интерфейсе.</p><div className="preview-chat-empty">Ответы модели не имитируются.</div><textarea aria-label="Чат не подключён" placeholder="Связь с Афиной не подключена" disabled/><button disabled>Отправка недоступна</button><small>Данные не покидают эту страницу через сетевые вызовы.</small></aside></div><footer className="preview-status"><span>Прототип 0.1 · проверка структуры и сценария</span><span>Hermes Desktop не изменён · Windows-запуск не проверен</span></footer></div>
}
createRoot(document.getElementById('root')!).render(<Preview/> )
