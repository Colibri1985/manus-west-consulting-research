export type PageId = 'home' | 'personal' | 'projects' | 'workshop' | 'finance' | 'knowledge'
export type DataClass = 'GREEN' | 'YELLOW' | 'RED' | 'BLACK'
export interface Project {
  id: string; name: string; goal: string; result: string; scope: string;
  owner: string; deadline: string; stages: string; dataClass: DataClass;
  revision: number; approvedRevision: number | null;
  status: 'draft' | 'review' | 'approved';
  next: string; domain: 'Рабочий' | 'Личный';
}
export interface JournalEntry { id: string; projectId: string; text: string; at: string }
export interface State { version: 1; projects: Project[]; journal: JournalEntry[] }
export const pages: {id: PageId; label: string; path: string; icon: string; sub: string}[] = [
  {id:'home',label:'Главное',path:'/athena-home',icon:'home',sub:'Решения и события, которым нужно ваше внимание'},
  {id:'personal',label:'Личное',path:'/athena-personal',icon:'account',sub:'Время, дела, здоровье и личные обязательства'},
  {id:'projects',label:'Проекты',path:'/athena-projects',icon:'project',sub:'Рамки и результаты под контролем Frigga'},
  {id:'workshop',label:'Мастерская',path:'/athena-workshop',icon:'tools',sub:'ИИ, разработка и автоматизация'},
  {id:'finance',label:'Финансы',path:'/athena-finance',icon:'graph',sub:'Личный и корпоративный контуры раздельно'},
  {id:'knowledge',label:'Знания',path:'/athena-knowledge',icon:'book',sub:'Два независимых пространства знаний'}
]
export const storageKey = 'athena:stage1:demo:v1'
export const initialState: State = {version:1,projects:[
  {id:'DEMO-001',name:'Развитие Афины',goal:'Проверить управляемый путь от запроса до согласованного проекта.',result:'Принятые рамки и список следующих действий.',scope:'Без подключения внешних систем и закрытых данных.',owner:'Андрей — владелец (пример)',deadline:'Не согласован',stages:'1. Рамки → согласованный паспорт.\n2. Проверка основы → техническое заключение.\n3. Пилот → отчёт о приёмке.',dataClass:'GREEN',revision:1,approvedRevision:null,status:'review',next:'Определить способ запуска на Windows 10',domain:'Личный'},
  {id:'DEMO-002',name:'Внедрение БИТ.ФИНАНС',goal:'Подготовить обследование финансовых процессов.',result:'Черновик карты процессов и требований.',scope:'Только методологическая подготовка; без рабочей базы.',owner:'Андрей — методология и руководство (пример)',deadline:'Не согласован',stages:'1. Обследование → карта процессов.\n2. Требования → согласованный реестр.\n3. Проверки → сценарии приёмки.',dataClass:'YELLOW',revision:1,approvedRevision:null,status:'draft',next:'Согласовать границы первой очереди',domain:'Рабочий'}
],journal:[]}
export function freshState(): State { return JSON.parse(JSON.stringify(initialState)) }
export function validState(value: unknown): value is State {
  if (!value || typeof value !== 'object') return false
  const s=value as State
  if(s.version!==1 || !Array.isArray(s.projects) || !Array.isArray(s.journal)) return false
  const ids=new Set<string>()
  const ok=s.projects.every(p=> {
    if(!p || typeof p!=='object' || !['id','name','goal','result','scope','owner','deadline','stages','next'].every(k=>typeof (p as unknown as Record<string,unknown>)[k]==='string')) return false
    if(!p.id || ids.has(p.id)) return false
    ids.add(p.id)
    return Number.isInteger(p.revision)&&p.revision>0 && ['draft','review','approved'].includes(p.status) && ['Личный','Рабочий'].includes(p.domain) && ['GREEN','YELLOW','RED','BLACK'].includes(p.dataClass) && (p.approvedRevision===null || (p.status==='approved'&&p.approvedRevision===p.revision)) && (p.status!=='approved'||p.approvedRevision===p.revision)
  })
  return ok && s.journal.every(j=>j && ['id','projectId','text','at'].every(k=>typeof (j as unknown as Record<string,unknown>)[k]==='string'))
}
export function log(s: State,p: Project,text: string): JournalEntry[] {return [{id:crypto.randomUUID(),projectId:p.id,text,at:new Date().toISOString()},...s.journal]}
export function decide(s: State,id: string,revision: number,accept: boolean): State {
  const p=s.projects.find(x=>x.id===id)
  if(!p || p.status!=='review' || p.revision!==revision) throw new Error('Предложение изменилось. Откройте актуальную версию.')
  const next={...p,status:accept?'approved' as const:'draft' as const,approvedRevision:accept?revision:null}
  return {...s,projects:s.projects.map(x=>x.id===id?next:x),journal:log(s,p,accept?`В демо согласована версия ${revision}. Это не разрешение внешних действий.`:`Версия ${revision} возвращена в черновик.`)}
}
export function revise(s: State,id: string,patch: Partial<Pick<Project,'name'|'goal'|'result'|'scope'|'owner'|'deadline'|'stages'|'next'|'domain'>>): State {
  const p=s.projects.find(x=>x.id===id);if(!p)throw new Error('Проект не найден')
  const next={...p,...patch,revision:p.revision+1,status:'draft' as const,approvedRevision:null}
  return {...s,projects:s.projects.map(x=>x.id===id?next:x),journal:log(s,p,`Создана версия ${next.revision}. Предыдущее согласование не действует.`)}
}
export function requestReview(s: State,id: string): State {
 const p=s.projects.find(x=>x.id===id);if(!p)throw new Error('Проект не найден')
 if(p.status!=='draft')throw new Error('На согласование отправляется только черновик')
 if(!p.goal.trim()||!p.result.trim()||!p.scope.trim())throw new Error('Нужны цель, результат и границы')
 return {...s,projects:s.projects.map(x=>x.id===id?{...x,status:'review' as const}:x),journal:log(s,p,`Версия ${p.revision} передана на демосогласование.`)}
}
