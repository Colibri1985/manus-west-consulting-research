import React from 'react'
import {AthenaPage} from './pages'
import {pages} from './model'
import css from './style.css'

// Structural subset of the pinned Desktop PluginContext; not a new host API.
export interface Contribution {
 id:string; area:string; title?:string; order?:number;
 render?:()=>React.ReactNode; data?:unknown;
}
export interface RegistrationContext { registerMany:(items:Contribution[])=>()=>void }
export const plugin={
 id:'athena-stage1',
 name:'Афина · прототип персонального пространства',
 description:'Шесть демостраниц. Без связи с агентом и внешних действий.',
 defaultEnabled:false,
 register(ctx:RegistrationContext){
  ctx.registerMany(pages.flatMap((p,i)=>[
   {id:'page-'+p.id,area:'routes',title:p.label,data:{path:p.path},render:()=> <><style>{css}</style><AthenaPage page={p.id}/></>},
   {id:'nav-'+p.id,area:'sidebar.nav',order:10+i,data:{label:p.label,codicon:p.icon,path:p.path}}
  ]))
 }
}
export default plugin
