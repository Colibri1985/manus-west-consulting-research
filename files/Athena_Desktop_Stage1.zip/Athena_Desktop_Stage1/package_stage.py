from pathlib import Path
import hashlib,json,subprocess,datetime,zipfile
root=Path(__file__).resolve().parent
upstream=root.parent/'hermes-upstream'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=upstream,text=True).strip()
paths=[
'apps/desktop/src/app/routes.ts','apps/desktop/src/contrib/registry.ts','apps/desktop/src/contrib/types.ts',
'apps/desktop/src/contrib/plugins.ts','apps/desktop/src/contrib/runtime-loader.ts','apps/desktop/src/contrib/plugin.ts',
'apps/desktop/src/plugins/kanban/plugin.tsx','apps/desktop/src/AGENTS.md','apps/desktop/BUILDING.md',
'apps/desktop/electron-builder.config.cjs','apps/desktop/DESIGN.md','apps/desktop/README.md',
'website/docs/user-guide/windows-native.md','website/docs/getting-started/platform-support.md','LICENSE']
records=[]
for rel in paths:
    data=(upstream/rel).read_bytes()
    target=root/'evidence'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
    records.append({'path':rel,'revision':sha,'sha256':hashlib.sha256(data).hexdigest(),'source':'https://github.com/NousResearch/hermes-agent/blob/'+sha+'/'+rel})
(root/'evidence/sources.json').write_text(json.dumps({'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':records},ensure_ascii=False,indent=2),encoding='utf-8')
archive=root.parent/'Athena_Desktop_Stage1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob('*'):
        if p.is_file() and not any(part in {'node_modules','__pycache__'} for part in p.relative_to(root).parts):
            z.write(p,Path('Athena_Desktop_Stage1')/p.relative_to(root))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert any(n.endswith('dist/Athena_Desktop_Prototype.html') for n in z.namelist())
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_integrity':'PASS','upstream_revision':sha,'upstream_worktree':subprocess.check_output(['git','status','--short'],cwd=upstream,text=True)},ensure_ascii=False,indent=2))
