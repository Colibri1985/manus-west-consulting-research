#!/usr/bin/env python3
"""Portable presentation assembly helpers. Python 3.10+, python-pptx for PPTX operations."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


def emit(value):
    print(json.dumps(value, ensure_ascii=False, indent=2))


def number(value, positive=False):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and (not positive or value > 0)


def validate(path):
    data = json.loads(path.read_text(encoding='utf-8'))
    errors = []
    if not isinstance(data, dict):
        return {}, ['Root must be an object']
    size = data.get('size', [13.333333, 7.5])
    if not isinstance(size, list) or len(size) != 2 or not all(number(v, True) for v in size):
        return data, ['size must contain two positive finite numbers']
    slides = data.get('slides')
    if not isinstance(slides, list) or not slides:
        return data, ['slides must be a nonempty array']
    slide_ids = set()
    for i, slide in enumerate(slides):
        loc = f'slide[{i}]'
        if not isinstance(slide, dict):
            errors.append(f'{loc}: must be an object'); continue
        sid = slide.get('id')
        if not isinstance(sid, str) or not sid or sid in slide_ids:
            errors.append(f'{loc}: unique nonempty string id required')
        else:
            slide_ids.add(sid)
        if not isinstance(slide.get('notes', ''), str):
            errors.append(f'{loc}: notes must be a string')
        if not re.fullmatch(r'[0-9a-fA-F]{6}', str(slide.get('background', 'FFFFFF'))):
            errors.append(f'{loc}: invalid background')
        elements = slide.get('elements')
        if not isinstance(elements, list) or not elements:
            errors.append(f'{loc}: elements must be a nonempty array'); continue
        ids = set()
        for j, e in enumerate(elements):
            label = f'{loc}.element[{j}]'
            if not isinstance(e, dict):
                errors.append(f'{label}: must be an object'); continue
            eid = e.get('id')
            if not isinstance(eid, str) or not eid or eid in ids:
                errors.append(f'{label}: unique nonempty string id required')
            else:
                ids.add(eid)
            kind = e.get('type')
            if kind not in ('text', 'rect', 'ellipse', 'line', 'image', 'table', 'chart'):
                errors.append(f'{label}: unsupported type {kind!r}'); continue
            if not all(number(e.get(k)) for k in ('x', 'y', 'w', 'h')):
                errors.append(f'{label}: numeric x/y/w/h required'); continue
            x, y, w, h = [e[k] for k in ('x', 'y', 'w', 'h')]
            if min(x, y, w, h) < 0 or (kind != 'line' and min(w, h) <= 0) or (kind == 'line' and w == h == 0):
                errors.append(f'{label}: invalid rectangle/line')
            if x+w > size[0]+0.002 or y+h > size[1]+0.002:
                errors.append(f'{label}: out of slide bounds')
            for field in ('color', 'fill', 'stroke', 'header_fill', 'header_color'):
                if field in e and not re.fullmatch(r'[0-9a-fA-F]{6}', str(e[field])):
                    errors.append(f'{label}: {field} must be six HEX digits')
            for field in ('size', 'width'):
                if field in e and not number(e[field], True):
                    errors.append(f'{label}: {field} must be positive')
            if 'margin' in e and (not number(e['margin']) or e['margin'] < 0):
                errors.append(f'{label}: margin must be nonnegative')
            if e.get('align', 'left') not in ('left', 'center', 'right'):
                errors.append(f'{label}: invalid align')
            if kind == 'text' and not isinstance(e.get('text'), str):
                errors.append(f'{label}: text must be a string')
            if kind == 'image':
                image_path = e.get('path')
                if not isinstance(image_path, str) or not (path.parent/image_path).is_file():
                    errors.append(f'{label}: image file missing')
            if kind == 'table':
                rows = e.get('rows')
                if not isinstance(rows, list) or not rows or not isinstance(rows[0], list) or not rows[0] or not all(isinstance(r, list) and len(r) == len(rows[0]) and all(isinstance(c, str) for c in r) for r in rows):
                    errors.append(f'{label}: rows must be a nonempty rectangular string matrix')
            if kind == 'chart':
                cats, series = e.get('categories'), e.get('series')
                if e.get('kind') not in ('bar', 'column', 'line', 'pie'):
                    errors.append(f'{label}: unsupported chart kind')
                if not isinstance(cats, list) or not cats or not all(isinstance(c, str) for c in cats):
                    errors.append(f'{label}: categories must be nonempty strings'); continue
                if not isinstance(series, list) or not series:
                    errors.append(f'{label}: series required'); continue
                if e.get('kind') == 'pie' and len(series) != 1:
                    errors.append(f'{label}: pie requires exactly one series')
                for s in series:
                    if not isinstance(s, dict) or not isinstance(s.get('name'), str) or not isinstance(s.get('values'), list) or len(s['values']) != len(cats) or not all(number(v) for v in s['values']):
                        errors.append(f'{label}: invalid series name/values')
                    elif e.get('kind') == 'pie' and (any(v < 0 for v in s['values']) or sum(s['values']) <= 0):
                        errors.append(f'{label}: pie values must be nonnegative with a positive total')
                colors = e.get('colors', ['006E69'])
                if not isinstance(colors, list) or not colors or not all(isinstance(c, str) and re.fullmatch(r'[0-9a-fA-F]{6}', c) for c in colors):
                    errors.append(f'{label}: invalid chart colors')
    return data, errors


def build(path, out):
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.dml.color import RGBColor
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
    from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
    from pptx.enum.text import PP_ALIGN
    from pptx.util import Inches, Pt
    data, errors = validate(path)
    if errors:
        emit({'ok': False, 'errors': errors}); return 1
    if out.exists():
        raise ValueError(f'Output already exists; choose a new version: {out}')
    p = Presentation()
    size = data.get('size', [13.333333, 7.5])
    p.slide_width, p.slide_height = [Inches(v) for v in size]
    p.core_properties.title = data.get('title', 'Presentation')
    font = data.get('font', 'Arial')
    rgb = RGBColor.from_string
    for spec in data['slides']:
        slide = p.slides.add_slide(p.slide_layouts[6])
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = rgb(spec.get('background', 'FFFFFF'))
        for e in spec['elements']:
            box = [Inches(e[k]) for k in ('x', 'y', 'w', 'h')]
            kind = e['type']
            if kind == 'text':
                shape = slide.shapes.add_textbox(*box)
                tf = shape.text_frame
                tf.word_wrap = True
                margin = Inches(e.get('margin', 0))
                tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = margin
                for k, line in enumerate(e['text'].split('\n')):
                    para = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
                    para.text = line
                    para.alignment = {'left': PP_ALIGN.LEFT, 'center': PP_ALIGN.CENTER, 'right': PP_ALIGN.RIGHT}[e.get('align', 'left')]
                    para.font.name = e.get('font', font)
                    para.font.size = Pt(e.get('size', 20))
                    para.font.bold = e.get('bold', False)
                    para.font.color.rgb = rgb(e.get('color', '172332'))
                if 'fill' in e:
                    shape.fill.solid(); shape.fill.fore_color.rgb = rgb(e['fill'])
            elif kind in ('rect', 'ellipse'):
                shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE if kind == 'rect' else MSO_SHAPE.OVAL, *box)
                shape.fill.solid(); shape.fill.fore_color.rgb = rgb(e.get('fill', 'FFFFFF'))
                if 'stroke' in e:
                    shape.line.color.rgb = rgb(e['stroke'])
                else:
                    shape.line.fill.background()
            elif kind == 'line':
                shape = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, box[0], box[1], box[0]+box[2], box[1]+box[3])
                shape.line.color.rgb = rgb(e.get('color', '172332'))
                shape.line.width = Pt(e.get('width', 1.5))
            elif kind == 'image':
                from PIL import Image
                image_path = (path.parent/e['path']).resolve()
                with Image.open(image_path) as im:
                    iw, ih = im.size
                scale = min(box[2]/iw, box[3]/ih)
                width, height = round(iw*scale), round(ih*scale)
                shape = slide.shapes.add_picture(str(image_path), round(box[0]+(box[2]-width)/2), round(box[1]+(box[3]-height)/2), width, height)
            elif kind == 'table':
                rows = e['rows']
                shape = slide.shapes.add_table(len(rows), len(rows[0]), *box)
                for ri, row in enumerate(rows):
                    for ci, value in enumerate(row):
                        cell = shape.table.cell(ri, ci)
                        cell.text = value
                        cell.margin_left = cell.margin_right = Inches(0.1)
                        if ri == 0:
                            cell.fill.solid(); cell.fill.fore_color.rgb = rgb(e.get('header_fill', '172332'))
                        for para in cell.text_frame.paragraphs:
                            para.font.name = font
                            para.font.size = Pt(e.get('size', 16))
                            para.font.bold = ri == 0
                            para.font.color.rgb = rgb(e.get('header_color', 'FFFFFF') if ri == 0 else e.get('color', '172332'))
            elif kind == 'chart':
                cd = CategoryChartData(); cd.categories = e['categories']
                for series in e['series']:
                    cd.add_series(series['name'], series['values'])
                ct = {'bar': XL_CHART_TYPE.BAR_CLUSTERED, 'column': XL_CHART_TYPE.COLUMN_CLUSTERED, 'line': XL_CHART_TYPE.LINE, 'pie': XL_CHART_TYPE.PIE}[e['kind']]
                shape = slide.shapes.add_chart(ct, *box, cd)
                chart = shape.chart
                chart.font.name = font; chart.font.size = Pt(e.get('size', 14))
                chart.has_legend = len(e['series']) > 1 or e['kind'] == 'pie'
                if chart.has_legend:
                    chart.legend.position = XL_LEGEND_POSITION.BOTTOM
                    chart.legend.include_in_layout = False
                colors = e.get('colors', ['006E69', '5D73A6', 'D69246'])
                for si, series in enumerate(chart.series):
                    if e['kind'] == 'line':
                        series.format.line.color.rgb = rgb(colors[si % len(colors)])
                    elif e['kind'] == 'pie':
                        for pi, point in enumerate(series.points):
                            point.format.fill.solid(); point.format.fill.fore_color.rgb = rgb(colors[pi % len(colors)])
                    else:
                        series.format.fill.solid(); series.format.fill.fore_color.rgb = rgb(colors[si % len(colors)])
            shape.name = f"{spec['id']}:{e['id']}"
        slide.notes_slide.notes_text_frame.text = spec.get('notes', '')
    out.parent.mkdir(parents=True, exist_ok=True)
    p.save(str(out))
    return inspect(out)


def inspect(path):
    from pptx import Presentation
    from pptx.util import Inches
    p = Presentation(str(path))
    result, errors = [], []
    for i, slide in enumerate(p.slides, 1):
        objects = []
        for s in slide.shapes:
            item = {'name': s.name, 'bounds_inches': [round(v/914400, 4) for v in (s.left, s.top, s.width, s.height)]}
            if min(s.left, s.top) < -Inches(0.002) or s.left+s.width > p.slide_width+Inches(0.002) or s.top+s.height > p.slide_height+Inches(0.002):
                errors.append(f'slide {i}, {s.name}: out of bounds')
            if s.has_text_frame:
                item['text'] = s.text
            if s.has_table:
                item['rows'] = [[c.text for c in row.cells] for row in s.table.rows]
            if s.has_chart:
                item['chart'] = {'categories': [c.label for c in s.chart.plots[0].categories], 'series': [{'name': se.name, 'values': list(se.values)} for se in s.chart.series]}
            objects.append(item)
        result.append({'slide': i, 'objects': objects, 'notes': slide.notes_slide.notes_text_frame.text if slide.has_notes_slide else ''})
    emit({'ok': not errors, 'file': str(path.resolve()), 'slides': result, 'errors': errors, 'visual_checked': False, 'scope': 'Object geometry and extracted content only; no text-fit or appearance verification.'})
    return 1 if errors else 0


def render(path, out):
    soffice = shutil.which('soffice') or shutil.which('libreoffice')
    pdftoppm = shutil.which('pdftoppm')
    if not soffice or not pdftoppm:
        raise RuntimeError('Render unavailable: LibreOffice and pdftoppm are both required')
    if not path.is_file():
        raise FileNotFoundError(path)
    # Creating a new directory prevents accidentally accepting stale PDF/PNG output.
    out.mkdir(parents=True, exist_ok=False)
    source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    with tempfile.TemporaryDirectory(prefix='presentation-studio-lo-') as profile:
        args = [soffice, '-env:UserInstallation='+Path(profile).as_uri(), '--headless', '--convert-to', 'pdf', '--outdir', str(out.resolve()), str(path.resolve())]
        result = subprocess.run(args, capture_output=True, text=True, timeout=180)
        pdf = out/(path.stem+'.pdf')
        if result.returncode or not pdf.is_file():
            raise RuntimeError('PDF export failed: '+(result.stdout+result.stderr)[-2500:])
    result = subprocess.run([pdftoppm, '-png', '-r', '120', str(pdf.resolve()), str((out/'slide').resolve())], capture_output=True, text=True, timeout=180)
    images = sorted(out.glob('slide-*.png'))
    if result.returncode or not images:
        raise RuntimeError('PNG render failed: '+result.stderr[-2500:])
    if hashlib.sha256(path.read_bytes()).hexdigest() != source_hash:
        raise RuntimeError('Source changed while rendering; discard this render and retry')
    manifest = {'source': str(path.resolve()), 'source_sha256': source_hash, 'pdf': str(pdf.resolve()), 'images': [str(p.resolve()) for p in images], 'rendered': True, 'visual_checked': False, 'target_app_checked': False}
    (out/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    emit(manifest)
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('preflight')
    for name in ('validate', 'build', 'inspect', 'render'):
        p = sub.add_parser(name)
        p.add_argument('input', type=Path)
        if name in ('build', 'render'):
            p.add_argument('output', type=Path)
    a = parser.parse_args()
    try:
        if a.command == 'preflight':
            emit({'python': sys.version.split()[0], 'executable': sys.executable, 'python_pptx': importlib.util.find_spec('pptx') is not None, 'soffice': shutil.which('soffice') or shutil.which('libreoffice'), 'pdftoppm': shutil.which('pdftoppm'), 'vision': 'Check agent tools separately; not detected by this script'})
            return 0
        if a.command == 'validate':
            _, errors = validate(a.input)
            emit({'ok': not errors, 'errors': errors, 'visual_checked': False})
            return 1 if errors else 0
        if a.command == 'build':
            return build(a.input, a.output)
        if a.command == 'inspect':
            return inspect(a.input)
        if a.command == 'render':
            return render(a.input, a.output)
    except (OSError, ValueError, RuntimeError, ImportError, subprocess.SubprocessError, KeyError, TypeError) as error:
        emit({'ok': False, 'error': str(error), 'visual_checked': False})
        return 1


if __name__ == '__main__':
    sys.exit(main())
