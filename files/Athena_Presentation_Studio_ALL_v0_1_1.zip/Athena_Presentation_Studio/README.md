# Presentation Studio — автономный прототип 0.1.1

Единый пакет для проверки Афиной. Это пересобранная самодостаточная редакция прототипа: примеры и тесты выполнены заново. Исходники чужих skills не копировались. Основной Hermes и сервер пользователя не менялись.

## Состав
- SKILL.md — инструкция последовательных ролей.
- WORKFLOW.md — контракты, границы и визуальный checklist.
- scripts/studio.py — сборка, рендер, импорт review и проверка актуальности.
- scripts/test_studio.py — 8 автоматических тестов.
- examples/demo.json — спецификация с Liberation Sans.
- examples/demo_local_dejavu.json — явно помеченный технический тест с DejaVu Sans.
- tested_sample/ — реальный PPTX, PDF, три PNG, notes, geometry, manifest и шаблон review.
- TEST_RESULTS.json — результаты повторной проверки.
- research/Findings.md — исходное исследование Афины.
- PACKAGE_MANIFEST.json — SHA-256 файлов пакета (сам файл manifest в свой перечень не входит).

## Зависимости и безопасность
Уже установленные Python, python-pptx, Pillow и fontconfig; для рендера — LibreOffice и pypdfium2. Ничего не устанавливается автоматически. Пакет не является sandbox: рендер запускать только в согласованном executor, не root, без недоверенных входов. Сетевые ограничения и контейнер задаются вне пакета. Не копировать в активные skills и не чинить LibreOffice без разрешения Андрея. Не подключать внешние API автоматически.

## Команды после согласования
```bash
python3 scripts/test_studio.py
python3 scripts/studio.py build examples/demo.json /approved/test-area/run-001
python3 scripts/studio.py status /approved/test-area/run-001
python3 scripts/studio.py render /approved/test-area/run-001
```
Каталог сборки должен быть новым. Не перезаписывать неуспешные запуски. Если шрифта нет — остановка, не скрытая подстановка. Если renderer не работает — PPTX остаётся draft, инфраструктуру отдельно диагностировать.

## Visual review
Просмотреть все полноразмерные PNG через существующий vision_analyze или вручную. Заполнить review_template.json: reviewer, method, decision=pass/needs_fixes и findings с severity=blocking/major/minor и description. Хеши не менять. Затем:
```bash
python3 scripts/studio.py review /approved/test-area/run-001 /path/to/filled_review.json
python3 scripts/studio.py status /approved/test-area/run-001
```
CLI проверяет актуальность review, а не честность просмотра: доверенный проверяющий обязан реально изучить изображения. Новый PPTX требует нового рендера и review. Финальное согласие пользователя отдельно, даже если visual_review=passed. Manifest не защищает от умышленной переписи всех хешей.

## Ограничения
Только два макета: roles_2x2 и process_4, четыре карточки каждый. Оценка вместимости через Pillow с запасом — не гарантия отображения во всех версиях Office. При LAYOUT_CONFLICT вернуть текст дизайнеру, не уменьшать шрифт автоматически. Интервью и vision исполняет Афина по инструкции; модельные вызовы не встроены. Нет автоматической оценки источников, лицензирования сторонних skills и публикации.

## Честный статус демонстрации
В этой среде требуемый Liberation Sans отсутствовал, поэтому используется отдельный DejaVu Sans-пример. Цвета Mimir сохранены, типографическое совпадение не заявлено. Выполнены 8 тестов и настоящий экспорт 3 слайдов в PDF/PNG. Визуальная приёмка не выполнялась: образец draft. PDF — именно экспорт PPTX, не отдельно собранный документ.
