import unittest,importlib.util,tempfile,copy
from pathlib import Path
R=Path(__file__).resolve().parents[1]
i=importlib.util.spec_from_file_location('studio',R/'scripts/studio.py');s=importlib.util.module_from_spec(i);i.loader.exec_module(s)
class Tests(unittest.TestCase):
 def setUp(self):self.v=s.read(R/'examples/demo_local_dejavu.json')
 def test_valid(self):s.validate(self.v)
 def test_approval(self):
  self.v['design_approved']=False
  with self.assertRaises(ValueError):s.validate(self.v)
 def test_duplicate(self):
  self.v['slides'][1]['id']='S01'
  with self.assertRaises(ValueError):s.validate(self.v)
 def test_layout(self):
  self.v['slides'][0]['layout']='arbitrary'
  with self.assertRaises(ValueError):s.validate(self.v)
 def test_build_and_no_overwrite(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'spec.json';s.write(f,self.v);r=Path(d)/'run';s.build(f,r)
   self.assertEqual(s.current(r)[1]['delivery_status'],'draft')
   with self.assertRaises(ValueError):s.build(f,r)
 def test_overflow(self):
  self.v['slides'][0]['cards'][0]['body']='Очень много слов '*90
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'spec.json';s.write(f,self.v)
   with self.assertRaisesRegex(ValueError,'LAYOUT_CONFLICT'):s.build(f,Path(d)/'run')
 def test_stale_pptx(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'spec.json';s.write(f,self.v);r=Path(d)/'run';s.build(f,r)
   with (r/'deck.pptx').open('ab') as q:q.write(b'x')
   with self.assertRaises(ValueError):s.current(r)
 def test_review_without_render(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'spec.json';s.write(f,self.v);r=Path(d)/'run';s.build(f,r)
   with self.assertRaises(ValueError):s.review(r,f)
if __name__=='__main__':unittest.main()
