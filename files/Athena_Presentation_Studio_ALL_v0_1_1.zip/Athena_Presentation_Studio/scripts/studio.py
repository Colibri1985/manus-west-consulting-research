import argparse,json,hashlib,subprocess,shutil,uuid
from pathlib import Path

def H(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def require(v,t):
 if not v:raise ValueError(t)
def font(name):
 p=subprocess.run(['fc-match','-f','%{family}\n%{file}',name],capture_output=True,text=True,check=True,timeout=10);v=p.stdout.splitlines()
 require(len(v)>1 and name.split(':')[0].lower() in v[0].lower(),'Required font missing: '+name);return v[1]
def validate(s):
 require(s.get('schema_version')=='0.1','Bad schema')
 for k in ['goal','audience','use_mode','reference_id']:require(s.get('brief',{}).get(k),'Missing brief '+k)
 require(s['brief'].get('approved') is True and s.get('design_approved') is True,'Approval required')
 require(1<=len(s['slides'])<=20,'Slide count')
 ids=[]
 for x in s['slides']:
  for k in ['id','title','takeaway','notes','sources']:require(x.get(k),'Missing '+k)
  require(x['layout'] in ['roles_2x2','process_4'] and len(x['cards'])==4,'Unsupported layout')
  if x['layout']=='process_4':require(len(x.get('relations',[]))==3 and all(x['relations']),'3 relation labels required')
  ids.append(x['id'])
  for c in x['cards']:require(c.get('heading') and c.get('body'),'Empty card')
 require(len(set(ids))==len(ids),'Duplicate slide id')
 for k in ['background','primary','text','muted','card','border','accent']:
  t=s['theme'][k];require(len(t)==6 and all(c in '0123456789abcdefABCDEF' for c in t),'Invalid color')
def current(run):
 r=Path(run).resolve();m=read(r/'manifest.json')
 require(H(r/'spec.json')==m['spec_sha256'],'Spec changed');require(H(r/'deck.pptx')==m['pptx_sha256'],'PPTX changed')
 return r,m
def build(spec,out):
 from pptx import Presentation
 from pptx.util import Inches,Pt
 from pptx.dml.color import RGBColor
 from pptx.enum.shapes import MSO_SHAPE
 from pptx.enum.text import MSO_AUTO_SIZE
 from PIL import ImageFont
 s=read(spec);validate(s);f=font(s['theme']['font']);fb=font(s['theme']['font']+':style=Bold')
 r=Path(out).resolve();require(not r.exists(),'Use a new output directory');r.mkdir(parents=True);write(r/'spec.json',s)
 deck=Presentation();deck.slide_width=Inches(13.333333);deck.slide_height=Inches(7.5);c=s['theme'];checks=[]
 def box(sl,x,y,w,h,col):
  sh=sl.shapes.add_shape(MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(col);sh.line.fill.background()
 def txt(sl,sid,name,x,y,w,h,t,sz,col,bold=False,parent=None):
  require(x>=0 and y>=0 and x+w<=13.333334 and y+h<=7.5,'Outside slide')
  if parent:
   a,b,cw,ch=parent;require(x>=a+.14 and y>=b+.14 and x+w<=a+cw-.14+1e-6 and y+h<=b+ch-.14+1e-6,'Card padding violated')
  ff=ImageFont.truetype(fb if bold else f,round(sz*4));lines=[]
  for par in t.split('\n'):
   line=''
   for word in par.split():
    require(ff.getlength(word)<=w*72*4*.95,'Word too long')
    nxt=(line+' '+word).strip()
    if line and ff.getlength(nxt)>w*72*4*.95:lines.append(line);line=word
    else:line=nxt
   lines.append(line)
  require(len(lines)*sz*1.22<=h*72*.95,'LAYOUT_CONFLICT '+sid+'/'+name)
  sh=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));sh.name=sid+'__'+name;tf=sh.text_frame;tf.word_wrap=False;tf.auto_size=MSO_AUTO_SIZE.NONE
  tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
  for i,line in enumerate(lines):
   p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name=s['theme']['font'];p.font.size=Pt(sz);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(col);p.line_spacing=Pt(sz*1.22);p.space_before=Pt(0);p.space_after=Pt(0)
  checks.append({'slide':sid,'object':name,'line_count':len(lines),'fit':'estimate_pass'})
 for n,x in enumerate(s['slides'],1):
  sl=deck.slides.add_slide(deck.slide_layouts[6]);sl.background.fill.solid();sl.background.fill.fore_color.rgb=RGBColor.from_string(c['background']);sid=x['id']
  box(sl,.55,.56,.055,.88,c['primary']);txt(sl,sid,'title',.8,.52,11.73,1.05,x['title'],28,c['primary'],True)
  txt(sl,sid,'subtitle',.8,1.6,11.73,.62,x.get('subtitle',''),16,c['muted'])
  for j,card in enumerate(x['cards']):
   if x['layout']=='roles_2x2':a=.8+j%2*6;b=2.55+j//2*1.55;w=5.74;h=1.34;hh=.36;by=.65;bh=.49
   else:a=.8+j*3;b=3.03;w=2.74;h=2.35;hh=.69;by=1.03;bh=1.06
   parent=(a,b,w,h);box(sl,a,b,w,h,c['card']);box(sl,a,b,w,.035,c['primary'])
   txt(sl,sid,f'card{j}_heading',a+.18,b+.2,w-.36,hh,card['heading'],19,c['primary'],True,parent)
   txt(sl,sid,f'card{j}_body',a+.18,b+by,w-.36,bh,card['body'],16,c['text'],False,parent)
  if x['layout']=='process_4':
   for j,t in enumerate(x['relations']):
    txt(sl,sid,f'relation{j}',.9+j*3,2.34,2.54,.45,t+' →',12,c['muted'])
    sh=sl.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW,Inches(3.59+j*3),Inches(4.02),Inches(.16),Inches(.15));sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(c['primary']);sh.line.fill.background()
  box(sl,.8,6.04,11.73,.012,c['border']);txt(sl,sid,'takeaway',.8,6.26,11.73,.68,x['takeaway'],17,c['primary'],True)
  txt(sl,sid,'footer',.8,7.1,10.3,.2,'ПРОТОТИП • ВИЗУАЛЬНАЯ ПРИЁМКА ОТДЕЛЬНО',9,c['muted']);txt(sl,sid,'page',12,7.1,.55,.2,str(n),9,c['muted'])
  sl.notes_slide.notes_text_frame.text=x['notes']+'\nИсточники:\n'+'\n'.join(x['sources'])
 deck.save(r/'deck.pptx');write(r/'geometry.json',{'status':'estimate_only','objects':checks})
 write(r/'manifest.json',{'run_id':uuid.uuid4().hex,'spec_sha256':H(r/'spec.json'),'pptx_sha256':H(r/'deck.pptx'),'slide_ids':[x['id'] for x in s['slides']],'slide_count':len(s['slides']),'build_status':'success','render_status':'not_attempted','visual_review_status':'not_reviewed','delivery_status':'draft'})
def render(run):
 r,m=current(run);require(not (r/'render').exists(),'Render folder exists; new build required');rd=r/'render';rd.mkdir();exe=shutil.which('libreoffice') or shutil.which('soffice')
 try:
  require(exe,'Renderer unavailable')
  p=subprocess.run([exe,'--headless','-env:UserInstallation='+(r/'profile').as_uri(),'--convert-to','pdf:impress_pdf_Export','--outdir',str(rd),str(r/'deck.pptx')],capture_output=True,text=True,timeout=120)
  (r/'render.stdout.txt').write_text(p.stdout);(r/'render.stderr.txt').write_text(p.stderr)
  pdf=rd/'deck.pdf';require(p.returncode==0 and pdf.exists() and pdf.stat().st_size>0,'PDF export failed')
  import pypdfium2
  doc=pypdfium2.PdfDocument(str(pdf));require(len(doc)==m['slide_count'],'Page count mismatch');images=[]
  for i in range(len(doc)):
   pg=doc[i];bitmap=pg.render(scale=1.5);im=bitmap.to_pil();f=rd/f'slide-{i+1:02d}.png';im.save(f);im.close();bitmap.close();pg.close();images.append({'slide_id':m['slide_ids'][i],'path':'render/'+f.name,'sha256':H(f)})
  doc.close();m.update(render_status='success',pdf_sha256=H(pdf),images=images);write(r/'manifest.json',m)
  write(r/'review_template.json',{'run_id':m['run_id'],'pptx_sha256':m['pptx_sha256'],'reviewer':'','method':'','slides':[{'slide_id':z['slide_id'],'image_sha256':z['sha256'],'decision':'not_reviewed','findings':[]} for z in images]})
 except Exception as e:
  m.update(render_status='failed',render_error=str(e));write(r/'manifest.json',m);raise

def verify(run):
 r,m=current(run)
 if m['render_status']=='success':
  require(H(r/'render/deck.pdf')==m['pdf_sha256'],'PDF changed')
  for z in m['images']:require(H(r/z['path'])==z['sha256'],'PNG changed')
 if m.get('review_sha256'):require(H(r/'review.json')==m['review_sha256'],'Review changed')
 return r,m

def review(run,file):
 r,m=verify(run);require(m['render_status']=='success','No successful render');v=read(file)
 require(v.get('reviewer') and v.get('method'),'Reviewer and method required')
 require(v.get('run_id')==m['run_id'] and v.get('pptx_sha256')==m['pptx_sha256'],'Stale review')
 require(len(v['slides'])==m['slide_count'] and sorted(z['slide_id'] for z in v['slides'])==sorted(m['slide_ids']),'Every slide exactly once')
 state='passed'
 for z in v['slides']:
  im=next(t for t in m['images'] if t['slide_id']==z['slide_id']);require(z['image_sha256']==im['sha256'],'Stale image')
  require(z['decision'] in ['pass','needs_fixes'] and isinstance(z['findings'],list),'Incomplete review')
  if z['decision']=='needs_fixes':require(z['findings'],'Describe fixes');state='needs_fixes'
  for f in z['findings']:
   require(f.get('severity') in ['blocking','major','minor'] and f.get('description'),'Invalid finding')
   if f['severity'] in ['blocking','major']:state='needs_fixes'
 write(r/'review.json',v);m.update(visual_review_status=state,delivery_status='reviewed_not_human_approved' if state=='passed' else 'needs_fixes',review_sha256=H(r/'review.json'));write(r/'manifest.json',m)

def main():
 a=argparse.ArgumentParser();s=a.add_subparsers(dest='cmd',required=True)
 b=s.add_parser('build');b.add_argument('spec');b.add_argument('outdir')
 for n in ['render','status']:
  b=s.add_parser(n);b.add_argument('run')
 b=s.add_parser('review');b.add_argument('run');b.add_argument('file')
 v=a.parse_args()
 try:
  if v.cmd=='build':build(v.spec,v.outdir)
  elif v.cmd=='render':render(v.run)
  elif v.cmd=='review':review(v.run,v.file)
  else:print(json.dumps(verify(v.run)[1],ensure_ascii=False,indent=2))
 except Exception as e:print(type(e).__name__+': '+str(e));return 1
 return 0
if __name__=='__main__':raise SystemExit(main())
