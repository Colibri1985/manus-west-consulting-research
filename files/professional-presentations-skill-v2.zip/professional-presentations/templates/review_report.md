# Presentation review report

- **Deck/version:**
- **Brief/version:**
- **Disposition:** Pass / Pass with disclosed limitations / Rework
- **Content review:** Complete / Incomplete (explain)
- **Visual review:** Every rendered slide inspected / Incomplete (explain)
- **Renderer/export used:**

## Content checks

- Objective and audience fit:
- Required points and scope:
- Storyline and takeaways:
- Claims, numbers, and source traceability:
- Assumptions, caveats, and ending/decision:

## Visual checks

- Slides rendered and inspected:
- Readability, clipping, overlap, and contrast:
- Alignment, spacing, and consistency:
- Charts, tables, diagrams, arrows, and labels:
- Match to design specification:

## Findings

| Severity | Slide/element | Evidence | Required fix | Owner | Status |
| --- | --- | --- | --- | --- | --- |
| Blocker / Major / Minor |  |  |  | Interviewer / Editorial designer / Assembler / Renderer | Open / Fixed |

## Final verification

- Rechecked affected slides:
- Final whole-deck visual pass:
- Remaining limitations or user decisions:
