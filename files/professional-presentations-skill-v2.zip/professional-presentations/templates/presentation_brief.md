# Presentation brief

- **Status:** draft / confirmed
- **Mode:** Quick / Full
- **Working title:**
- **Purpose:** What should the audience understand, decide, or do?
- **Primary audience:** Prior knowledge, needs, likely questions/objections
- **Use context:** Live talk / read-ahead / handout / defense / other
- **Depth and scope:** Executive / management / technical / mixed; desired slide count or duration
- **Core argument:** One sentence
- **Decision or next action:**
- **Required content:**
- **Excluded or sensitive content:**
- **Sources:** List files/URLs, IDs, status (approved/draft/assumption), and any conflicts
- **Design reference/template:** Include reference ID/version and allowed changes
- **Deliverables:** Editable PPTX / PDF / speaker notes / other
- **Acceptance criteria:**
- **Assumptions:** Clearly separate from confirmed facts
- **Open material questions:** Ask only questions that block a sound result
- **Approvals:** What has the user approved, and when?
