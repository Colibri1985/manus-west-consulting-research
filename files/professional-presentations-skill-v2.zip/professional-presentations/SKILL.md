---
name: professional-presentations
description: "Creates professional, decision-focused presentations through a controlled sequence: brief, editorial storyboard and design system, editable slide assembly, and independent content and visual review. Use for new decks, substantial redesigns, executive or technical presentations, and source-heavy PPTX/PDF work."
license: "Personal use"
metadata:
  author: "Andrey"
  version: "2.0.0"
  category: "productivity"
---

# Professional presentations

Treat a presentation as a visual argument for a real audience, not a document split across slides. Run the four functions below in sequence as one assistant workflow. They are working roles, not four autonomous agents. Keep the user-facing conversation with the coordinating assistant; do not make the assembler invent the story or make the reviewer fix the deck silently.

Use the templates in `templates/` relative to this skill when available. Adapt them to the task; preserve the required fields and decisions even when using another format.

## Choose a mode

- **Quick mode:** use for a small, low-stakes deck (usually up to 6 slides), a clear brief, familiar style, and straightforward evidence. Keep artifacts concise and internal unless the user asks for them. Still run all four functions; do not skip the final review.
- **Full mode:** use for important or high-stakes decks, more than 6 slides, substantial source material, complex diagrams/data, uncertain requirements, a new visual style, or major redesigns. Save the brief, storyboard, design specification, and review report with the project files. Add a prototype checkpoint for a large deck, high-stakes delivery, or new style.
- If uncertain, choose Full mode for consequential work; otherwise choose Quick mode and state any material assumptions. Never turn a clear request into a long questionnaire.

## 1. Interviewer — define the assignment

Inspect the user's request, supplied files, existing deck, template, brand references, and constraints before asking questions. Extract what is already known. Establish only information that materially affects the result:

- purpose and the main decision, action, or change in understanding sought;
- audience, prior knowledge, expected objections, and appropriate depth;
- use context: live talk, read-ahead, handout, defense, or other;
- desired length or duration, required topics, exclusions, and acceptance criteria;
- approved sources, source status, confidentiality limits, and unresolved conflicts;
- visual references or template, permitted changes, and deliverables (editable PPTX, PDF, notes, etc.).

Ask only about material gaps that cannot be resolved safely from context. Make reasonable defaults for routine choices and label assumptions. If sources or instructions conflict, show the conflict and ask for a decision rather than choosing silently. Do not send confidential content to an external tool or service unless the user has authorized it.

Create a concise `presentation_brief.md` (use `templates/presentation_brief.md`). Record open questions and assumptions separately from confirmed requirements. In Full mode, get the user's decision on any blocking question before design begins.

## 2. Editorial designer — plan meaning, then visuals

Work in this order; do not select attractive layouts first and force the story into them.

1. **Argument and storyboard:** define the one-sentence core argument, then plan every slide. For each slide record its purpose, audience question, takeaway headline, key message, supporting content, evidence/source locator, relation to adjacent slides, and any speaker notes or constraints. Give each slide one primary claim. Use a source ID or a precise source locator for material evidence; distinguish facts, interpretation, assumptions, and recommendations.
2. **Design system and composition:** only after the story is coherent, specify canvas, visual references, colors and their semantic roles, typography, grid/margins, spacing, reusable components, chart/table rules, line and arrow conventions, image treatment, and accessibility rules. For each slide, choose a visual type and layout that express its meaning. Record whether arrows mean sequence, causality, or a relationship; use no connectors when none are implied. Keep a responsibility map distinct from a process flow.
3. **Prototype checkpoint:** for a large or high-stakes deck, or any new visual style, create 2–3 representative slides before full assembly: typically a title, a normal content slide, and the most difficult chart/diagram. Ask the user to approve the story and visual direction before proceeding. If the user explicitly requested end-to-end work without a pause, continue from the best-supported direction but record that the prototype was not user-approved; never imply otherwise. Quick mode may omit this checkpoint when the style and task are familiar.

Use `templates/storyboard.yaml` and `templates/design_spec.json` (or equivalent artifacts). Preserve reference identity and version in the design specification. Avoid unsupported claims, decorative visuals without a purpose, and content density that would require tiny type. For Андрей's БИТ.ФИНАНС materials, follow the supplied scheme-album style and include a block-color legend; use actual supplied design tokens rather than guessing a generic corporate palette.

## 3. Assembler — implement the approved plan

Use the PPTX creation/editing tools or skill actually available in the target Hermes environment. Discover and follow their current documented workflow; do not assume a tool name, path, or export capability. Preserve the user's editable template/master when supplied.

Implement the approved brief, storyboard, and design specification faithfully. Build an editable PPTX, not a deck flattened into slide images. Preserve source notes and useful speaker notes. Export a PDF only when requested or useful and a real export is available. Do not silently change the argument, remove qualifications, add facts, reinterpret relationships, substitute a visual style, or shrink text until it is unreadable.

When the approved plan cannot fit or be implemented, stop on that item and report a `BUILD_BLOCKER` with slide ID, conflicting element, reason, and viable options (shorten, redesign, split, move detail to notes/appendix, or keep as-is). Return meaning or design choices to the editor-designer; ask the user when the choice changes scope, meaning, or agreed deliverables. Route renderer/export failures as technical issues rather than changing the content to work around them.

Run available structural checks for slide count, missing content, bounds, overlaps, fonts, and file integrity. These checks are useful but do not replace rendered visual review.

## 4. Reviewer — independently inspect content and every rendered slide

Review against the brief and source material, not merely against the assembler's output. Keep content review separate from visual review.

**Content review:** verify the purpose and audience fit; complete coverage of required points; logical flow and supported conclusions; source traceability for material facts and numbers; clear distinctions between fact, estimate, interpretation, and recommendation; explicit chart units, periods, and denominators; and a clear ending or requested decision. Flag omissions, contradictions, unsupported claims, and source conflicts.

**Visual review:** render the actual final deck and inspect every slide image individually at a useful presentation size. A contact sheet may help compare consistency but does not replace slide-by-slide inspection. Check clipping, overflow, overlap, legibility, contrast, reading order, alignment, spacing, line breaks, labels, charts, tables, arrows/relationships, consistency with the design specification, and accidental placeholders. If rendering is unavailable, state plainly that visual verification was not completed; do not claim it.

Create a `review_report.md` (use `templates/review_report.md` in Full mode) with disposition, checks performed, and findings. For each finding record severity, slide/element, evidence, required fix, and owner. Route findings to the function that can correct them:

| Defect | Owner |
| --- | --- |
| Wrong/missing objective, audience, scope, or acceptance criterion | Interviewer; clarify with the user if material |
| Weak argument, missing evidence, overload, or unclear takeaway | Editorial designer |
| Wrong visual form, ambiguous diagram, or unsuitable composition | Editorial designer |
| Coordinates, sizing, color/style token, font, or implementation mismatch | Assembler |
| Export, rendering, or file-integrity failure | Technical renderer/tooling task |

Do not “fix” a meaning or design defect by shrinking text or making an unapproved content change. After correction, re-check every affected slide and perform a final visual pass across the whole deck; repeat the content checks for any changed claims. Resolve all blockers before delivery or disclose them clearly. If a defect cannot be corrected within the agreed scope, return it to the user for a decision.

## Evidence and visual standards

- Never invent statistics, quotations, citations, dates, stakeholder positions, or project status. Mark unknowns as gaps or narrow the claim.
- Trace each material number to the original source and period. For spreadsheets, verify the source workbook and relevant sheet/cell/table; recalculate when needed rather than trusting an unverified summary.
- Put concise source notes near claims/charts and a source list in the appendix for research-heavy decks. Include publisher/date and URL where relevant.
- Use charts for comparisons or trends, process diagrams for sequence, responsibility maps for ownership, tables for precise lookup, and short statements for a single insight. Label chart units, periods, and denominators; use honest scales.
- Prefer readable body text (typically 18 pt or larger when the format permits), adequate contrast, consistent alignment, generous whitespace, and a restrained palette. Never encode meaning with color alone.
- Use illustrative or generated images as illustrations, not documentary evidence. Preserve attribution and provide useful alt text or equivalent notes where supported.

## Deliver

Provide the editable PPTX and any requested/created PDF. Briefly state the selected mode, purpose/audience assumptions, files, review status, and any material limitation or unresolved finding. Do not claim that sources were verified, a PDF was exported, or slides were visually checked unless that work was actually completed.
