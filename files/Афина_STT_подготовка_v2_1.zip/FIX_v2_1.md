# v2.1: исправление ошибочного сравнения идентификаторов

## Что установлено реально

Владелец передал вывод docker inspect/image inspect с сервера:
локальный Id и Image рабочего gateway равны sha256:9774f4f39a9bb8c2f68ce728ed5e99ddbad282163be56764afacf88ed952b784.
RepoDigests содержит тот же закреплённый repository digest; платформа linux/amd64.

Config blob из публичного registry получен повторно. Его SHA-256 сверена с config
descriptor закреплённого platform manifest: sha256:373ddd5e6649f525b17993e1c885cdf1352127f8e98fd329140a73237125e52f.
Все 37 RootFS diff IDs из вывода владельца совпали с config.rootfs.diff_ids, включая порядок.
Это не сжатые registry layer digests: эти два вида checksum не смешиваются.
Fingerprint компактного JSON ordered diff_ids приведён в evidence/base-image/runtime-identity.json.
Причину, по которой daemon показывает index digest в поле Id, не устанавливали и
не выдаём предположение о backend/version за факт.

## Ошибка и исправление

В v2 config digest был ошибочно объявлен обязательным значением Docker Id. Поэтому
preflight останавливался до docker exec policy probe. Простая замена константы или
удаление проверки не применялись.

В v2.1 проверяются совместно:
- локальный Id принадлежит закрытому набору config/index/platform descriptor закреплённого образа;
- gateway.Image совпадает с этим локальным Id;
- RepoDigests содержит точный исходный BASE reference;
- платформа linux/amd64;
- тип RootFS layers, количество 37 и fingerprint ВСЕГО упорядоченного списка diff_ids.

Фактический локальный Id сохраняется как base_image_id в preflight receipt отдельно
от base_registry_config_digest. Gate и rollback проверяют именно сохранённый Id.
Проверка хэшей выбранных исходников ЖИВОГО контейнера не удалена: совпадение RootFS
образа не доказывает отсутствие изменений в writable layer или bind mounts.

## Границы изменения

Архитектура, STT runner, зависимости, модель, интеграционный тест, Dockerfile и Compose
не менялись. В contract-hashes.json исправлено только имя метаданных base_image_id →
base_registry_config_digest; fingerprint build context поэтому изменился намеренно.
Политика исполнения/auto-install/approvals не ослаблена и не менялась на сервере.

30 unit-тестов прошли, из них 10 новых проверяют форму идентификатора, RepoDigests,
платформу, gateway image, состав и порядок слоёв. Это тесты на синтетических данных,
НЕ ASR PASS. Исходные проверки отсутствия receipts и изменённой сборки сохранены.
Проверен состав ZIP и хэши MANIFEST. Реальных direct/integration ASR receipts нет.

## Применение отдельно от v2

Это полный пакет, не неполный patch. Новая папка:
/srv/hermes-agent/athena-stt-prep-v2_1
Старую /srv/hermes-agent/athena-stt-prep-v2 не перезаписывать и не редактировать.
Служебные результаты новой версии изолированы:
/srv/hermes-agent/athena-stt-state/v2_1

Перенос и проверенная распаковка согласуются отдельно. Затем только preflight:
cd /srv/hermes-agent/athena-stt-prep-v2_1
sudo env ATHENA_APPROVE_PREFLIGHT=YES python3 control.py preflight

Даже если идентичность образа подтверждена, проверка policy/UID/исходников может выдать
отдельный STOP. Это не разрешение изменить security или запустить build/download.
Сборка, скачивание модели, ASR-тесты и переключение по-прежнему требуют отдельных согласований.
Исполнитель не выполнял операций с production Docker/config/gateway при подготовке v2.1.
