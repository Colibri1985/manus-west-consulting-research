"""Synthetic identity cases only. No Docker calls, no ASR acceptance receipts."""
import copy,hashlib,importlib.util,json,tempfile,unittest,sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('identity_control',ROOT/'control.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)

class IdentityTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  root=Path(self.tmp.name);(root/'evidence/base-image').mkdir(parents=True)
  self.layers=['sha256:'+('a'*64),'sha256:'+('b'*64)]
  self.e={'registry_config_digest':'sha256:'+('1'*64),'registry_index_digest':'sha256:'+('2'*64),'platform_manifest_digest':'sha256:'+('3'*64),'rootfs_type':'layers','rootfs_diff_ids_count':2,'ordered_diff_ids_json_sha256':hashlib.sha256(json.dumps(self.layers,separators=(',',':')).encode()).hexdigest(),'os':'linux','architecture':'amd64'}
  (root/'evidence/base-image/runtime-identity.json').write_text(json.dumps(self.e))
  self.p=patch.object(c,'ROOT',root);self.p.start();self.addCleanup(self.p.stop)
  self.base={'Id':self.e['registry_index_digest'],'RepoDigests':[c.BASE],'Os':'linux','Architecture':'amd64','RootFS':{'Type':'layers','Layers':list(self.layers)}}
 def check(self,g=None):
  return c.validate_base_identity(g or {'Image':self.base['Id']},self.base)
 def test_daemon_index_id_allowed_with_all_checks(self):self.assertEqual(self.check(),self.base['Id'])
 def test_config_id_allowed_with_all_checks(self):
  self.base['Id']=self.e['registry_config_digest'];self.assertEqual(self.check(),self.base['Id'])
 def test_platform_id_allowed_with_all_checks(self):
  self.base['Id']=self.e['platform_manifest_digest'];self.assertEqual(self.check(),self.base['Id'])
 def test_unrelated_id_rejected(self):
  self.base['Id']='sha256:'+('4'*64)
  with self.assertRaises(RuntimeError):self.check()
 def test_wrong_platform_rejected(self):
  self.base['Architecture']='arm64'
  with self.assertRaises(RuntimeError):self.check()
 def test_missing_repo_digest_rejected(self):
  self.base['RepoDigests']=[]
  with self.assertRaises(RuntimeError):self.check()
 def test_changed_layer_rejected(self):
  self.base['RootFS']['Layers'][0]='sha256:'+('c'*64)
  with self.assertRaises(RuntimeError):self.check()
 def test_reordered_layers_rejected(self):
  self.base['RootFS']['Layers'].reverse()
  with self.assertRaises(RuntimeError):self.check()
 def test_layer_count_changed_rejected(self):
  self.base['RootFS']['Layers'].pop()
  with self.assertRaises(RuntimeError):self.check()
 def test_wrong_gateway_image_rejected(self):
  with self.assertRaises(RuntimeError):self.check({'Image':'sha256:'+('5'*64)})
if __name__=='__main__':unittest.main(verbosity=2)
